# Business Associate Agreement (Extract)

This Agreement is entered into by and between TeleHealth Connect (Covered Entity) and [Vendor Name] (Business Associate).

1. Permitted Uses and Disclosures: The Business Associate agrees to use or disclose Protected Health Information (PHI) only as permitted or required by this Agreement or as required by law.
2. Safeguards: The Business Associate shall use appropriate administrative, physical, and technical safeguards to prevent the unauthorized use or disclosure of PHI.
3. Breach Notification: The Business Associate agrees to mitigate, to the extent practicable, any harmful effect of a use or disclosure of PHI in violation of this Agreement, and report any data breach to the Covered Entity within 72 hours of discovery.
